extends Node2D
class_name SpawnManager

## Dedicated SpawnManager for Night Harvest
##
## Controls where zombies and animals spawn using editor-draggable Marker2D nodes.
##
## Scene Structure:
## SpawnManager (Node2D)
## ├── ZombieSpawnPoint (Marker2D) [EXACTLY ONE DESIGNATED SPAWN POINT]
## ├── AnimalSpawnPoints (Node2D)
## │   ├── SpawnPoint01 (Marker2D)
## │   └── ...
## └── ZombieSpawnTimer (Timer, 60s)
##
## Features:
## - Exactly ONE designated ZombieSpawnPoint (movable in Godot editor)
## - Zero random coordinate generation or multiple spawn points for zombies
## - 10 zombies spawned every 60 seconds from the SAME point
## - Uses Godot's Timer node for interval tracking
## - Day/Night integration: begins 60s waves at night, stops at day

@export_group("Zombie Spawning")
@export var zombie_scene: PackedScene = preload("res://Scenes/zombie.tscn")
@export var zombies_per_wave: int = 10
@export var spawn_interval: float = 60.0

@export_group("Animal Spawning")
@export var animal_scene: PackedScene = preload("res://Scenes/chicken.tscn")
@export var animal_scenes: Array[PackedScene] = [
	preload("res://Scenes/chicken.tscn"),
	preload("res://Scenes/cow.tscn"),
	preload("res://Scenes/pig.tscn"),
	preload("res://Scenes/sheep.tscn")
]
@export var max_animals: int = 5

# --- Internal State & Node References ---
var _game_clock: Node = null
var _spawned_zombies: Array[Node2D] = []
var _spawned_animals: Array[Node2D] = []

@onready var zombie_spawn_point: Marker2D = get_node_or_null("ZombieSpawnPoint")
@onready var zombie_spawn_timer: Timer = get_node_or_null("ZombieSpawnTimer")


func _ready() -> void:
	add_to_group("spawn_manager")
	
	# Setup ZombieSpawnTimer
	if not zombie_spawn_timer:
		zombie_spawn_timer = Timer.new()
		zombie_spawn_timer.name = "ZombieSpawnTimer"
		add_child(zombie_spawn_timer)
	
	zombie_spawn_timer.wait_time = spawn_interval
	if not zombie_spawn_timer.timeout.is_connected(_on_zombie_spawn_timer_timeout):
		zombie_spawn_timer.timeout.connect(_on_zombie_spawn_timer_timeout)
	
	call_deferred("_connect_game_clock")


func _connect_game_clock() -> void:
	var clock_nodes := get_tree().get_nodes_in_group("game_clock")
	for c in clock_nodes:
		if is_instance_valid(c):
			_game_clock = c
			break
	
	if _game_clock:
		_game_clock.night_started.connect(_on_night_started)
		_game_clock.night_ended.connect(_on_night_ended)
		
		# Initial state based on current period
		if _game_clock.is_night():
			_start_zombie_spawning()
		else:
			_stop_zombie_spawning()
			spawn_animals()
	else:
		# Fallback when running standalone scene
		spawn_animals()


# ==============================================================================
# SPAWN POINT ACCESSORS
# ==============================================================================

## Returns the single designated ZombieSpawnPoint Marker2D
func get_zombie_spawn_point() -> Marker2D:
	if zombie_spawn_point and is_instance_valid(zombie_spawn_point):
		return zombie_spawn_point
	var pt = get_node_or_null("ZombieSpawnPoint")
	if pt and pt is Marker2D:
		return pt
	return null


## Backward-compatible array accessor returning the single designated spawn point
func get_zombie_spawn_points() -> Array[Node2D]:
	var pt := get_zombie_spawn_point()
	if pt:
		return [pt]
	return []


## Returns all Marker2D / Node2D spawn points under AnimalSpawnPoints
func get_animal_spawn_points() -> Array[Node2D]:
	var points: Array[Node2D] = []
	var container := get_node_or_null("AnimalSpawnPoints")
	if container:
		for child in container.get_children():
			if child is Node2D:
				points.append(child)
	return points


# ==============================================================================
# CONTROLLED ZOMBIE SPAWNING (10 Zombies every 60s from ONE Location)
# ==============================================================================

## Spawns exactly zombies_per_wave (10) zombies from the single ZombieSpawnPoint.
## Zero randomized coordinates. All zombies spawn from the same designated point.
func spawn_zombies() -> Array[Node2D]:
	if not zombie_scene:
		return []
	
	var pt := get_zombie_spawn_point()
	if not pt:
		push_warning("SpawnManager: No ZombieSpawnPoint found!")
		return []
	
	var target_parent := _get_entity_parent()
	var newly_spawned: Array[Node2D] = []
	
	for i in range(zombies_per_wave):
		var zombie = zombie_scene.instantiate()
		target_parent.add_child(zombie)
		zombie.global_position = pt.global_position
		_spawned_zombies.append(zombie)
		newly_spawned.append(zombie)
	
	print("[SpawnManager] Wave spawned: %d zombies at %s" % [newly_spawned.size(), pt.global_position])
	return newly_spawned


func _on_zombie_spawn_timer_timeout() -> void:
	spawn_zombies()


func _start_zombie_spawning() -> void:
	if zombie_spawn_timer:
		zombie_spawn_timer.wait_time = spawn_interval
		zombie_spawn_timer.start()
	# Spawn initial wave of 10 zombies upon night arrival
	spawn_zombies()


func _stop_zombie_spawning() -> void:
	if zombie_spawn_timer:
		zombie_spawn_timer.stop()


## Cleans up active spawned zombies
func clear_zombies() -> void:
	_clean_tracked_zombies()
	for z in _spawned_zombies:
		if is_instance_valid(z):
			z.queue_free()
	_spawned_zombies.clear()


# ==============================================================================
# ANIMAL SPAWNING
# ==============================================================================

## Spawns animals at available AnimalSpawnPoints up to max_animals.
func spawn_animals() -> Array[Node2D]:
	_clean_tracked_animals()
	var available_points := get_animal_spawn_points()
	if available_points.is_empty():
		return []
	
	var slots_available := maxi(0, max_animals - _spawned_animals.size())
	var spawn_count := mini(slots_available, available_points.size())
	
	var newly_spawned: Array[Node2D] = []
	var target_parent := _get_entity_parent()
	
	for i in range(spawn_count):
		var spawn_pt: Node2D = available_points[i]
		var chosen_scene: PackedScene = animal_scene
		if not animal_scenes.is_empty():
			chosen_scene = animal_scenes[i % animal_scenes.size()]
		
		if not chosen_scene:
			continue
		
		var animal = chosen_scene.instantiate()
		target_parent.add_child(animal)
		animal.global_position = spawn_pt.global_position
		_spawned_animals.append(animal)
		newly_spawned.append(animal)
	
	return newly_spawned


## Clears active spawned animals
func clear_animals() -> void:
	_clean_tracked_animals()
	for a in _spawned_animals:
		if is_instance_valid(a):
			a.queue_free()
	_spawned_animals.clear()


# ==============================================================================
# DAY / NIGHT SIGNALS
# ==============================================================================

func _on_night_started() -> void:
	_start_zombie_spawning()


func _on_night_ended() -> void:
	_stop_zombie_spawning()
	clear_zombies()
	spawn_animals()


# ==============================================================================
# HELPERS
# ==============================================================================

func _clean_tracked_zombies() -> void:
	var valid: Array[Node2D] = []
	for z in _spawned_zombies:
		if is_instance_valid(z) and not z.get("is_dead"):
			valid.append(z)
	_spawned_zombies = valid


func _clean_tracked_animals() -> void:
	var valid: Array[Node2D] = []
	for a in _spawned_animals:
		if is_instance_valid(a):
			valid.append(a)
	_spawned_animals = valid


func _get_entity_parent() -> Node:
	var parent := get_parent()
	if parent:
		return parent
	return get_tree().current_scene if get_tree() else self


func _get_player() -> CharacterBody2D:
	var players := get_tree().get_nodes_in_group("player")
	for p in players:
		if is_instance_valid(p) and p is CharacterBody2D:
			return p
	return null
