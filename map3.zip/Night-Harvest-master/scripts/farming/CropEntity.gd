extends Node2D
class_name CropEntity

## Visual and logical instance of a planted crop in the game world.
## Supports multi-stage growth, stage-reset watering, and renewable seed yield.

signal stage_changed(new_stage: int)
signal crop_matured()
signal crop_harvested(crop_id: String)

@export var crop_data: Resource

var crop_id: String = ""
var growth_stage: int = 0
var max_growth_stage: int = 3
var growth_progress_minutes: float = 0.0
var watered: bool = false
var mature: bool = false
var grid_pos: Vector2i = Vector2i.ZERO
var planted_day: int = 1
var planted_hour: int = 6
var planted_minute: int = 0

@onready var sprite: Sprite2D = $Sprite2D
@onready var mature_indicator: Sprite2D = get_node_or_null("MatureIndicator")

var _bob_time: float = 0.0


func _ready() -> void:
	add_to_group("crops")
	if not sprite:
		sprite = get_node_or_null("Sprite2D")
	if not sprite:
		sprite = Sprite2D.new()
		sprite.name = "Sprite2D"
		add_child(sprite)
	
	if crop_data and not crop_data.stage_textures.is_empty():
		max_growth_stage = crop_data.stage_textures.size() - 1
	
	_update_visuals()


func _process(delta: float) -> void:
	if mature and sprite:
		# Gentle floating bounce when crop is mature and ready for harvest
		_bob_time += delta * 4.0
		sprite.position.y = sin(_bob_time) * 1.2
	elif sprite and sprite.position.y != 0.0:
		sprite.position.y = 0.0


func setup(p_data: Resource, p_grid_pos: Vector2i, p_watered: bool = false, current_time: Dictionary = {}) -> void:
	crop_data = p_data
	crop_id = p_data.crop_id
	grid_pos = p_grid_pos
	watered = p_watered
	growth_stage = 0
	growth_progress_minutes = 0.0
	mature = false
	
	if crop_data and not crop_data.stage_textures.is_empty():
		max_growth_stage = crop_data.stage_textures.size() - 1
	else:
		max_growth_stage = 3
	
	planted_day = current_time.get("day", 1)
	planted_hour = current_time.get("hour", 6)
	planted_minute = current_time.get("minute", 0)
	
	_update_visuals()


## Advances growth by game time minutes. Called by FarmingManager on GameClock ticks.
## Crops grow after being watered once, reaching maturity over 30 seconds.
func advance_game_minute(amount: float = 1.0) -> void:
	if mature:
		return
	
	# Crops strictly require water for growth progress if requires_water is true
	if crop_data and crop_data.requires_water and not watered:
		return
	
	growth_progress_minutes += amount
	
	var duration: float = crop_data.growth_duration_game_minutes if crop_data else 30.0
	var stages_total: int = max(1, max_growth_stage)
	var time_per_stage: float = duration / float(stages_total)
	
	# Determine target stage based on accumulated watered growth minutes
	var calculated_stage: int = clampi(int(growth_progress_minutes / time_per_stage), 0, max_growth_stage)
	
	if calculated_stage > growth_stage:
		growth_stage = calculated_stage
		_update_visuals()
		stage_changed.emit(growth_stage)
		
		if growth_stage >= max_growth_stage:
			mature = true
			crop_matured.emit()



## Checks if the crop can be watered
func can_be_watered() -> bool:
	if mature:
		return false
	if not (crop_data and crop_data.requires_water):
		return false
	return not watered


func set_watered(p_watered: bool) -> void:
	watered = p_watered
	_update_visuals()


func _update_visuals() -> void:
	if not sprite:
		return
	
	if crop_data:
		var tex = crop_data.get_stage_texture(growth_stage)
		if tex:
			sprite.texture = tex
	
	# Visual feedback:
	# Mature: gentle golden highlight
	# Watered: moist glistening light blue tint
	# Dry: standard white
	if mature:
		sprite.modulate = Color(1.08, 1.08, 0.95, 1.0)
	elif watered:
		sprite.modulate = Color(0.85, 0.95, 1.15, 1.0)
	else:
		sprite.modulate = Color.WHITE


func can_harvest() -> bool:
	return mature or growth_stage >= max_growth_stage


func is_mature() -> bool:
	return can_harvest()


## Harvests the mature crop. Returns crop yield + renewable seeds.
func harvest() -> Dictionary:
	if not can_harvest():
		return {}
	
	var harvest_item: String = crop_data.harvest_item_id if crop_data else "carrot"
	var yield_amt: int = randi_range(crop_data.harvest_yield_min, crop_data.harvest_yield_max) if crop_data else 1
	var seed_item: String = crop_data.seed_id if crop_data else "carrot_seed"
	var seed_yield_amt: int = randi_range(crop_data.seed_yield_min, crop_data.seed_yield_max) if crop_data else 1
	var xp_reward: int = crop_data.xp_reward if crop_data else 10
	
	crop_harvested.emit(harvest_item)
	queue_free()
	
	return {
		"item_id": harvest_item,
		"amount": yield_amt,
		"seed_id": seed_item,
		"seed_amount": seed_yield_amt,
		"xp": xp_reward
	}


## Serializable representation for future save/load integration
func get_save_data() -> Dictionary:
	return {
		"crop_id": crop_id,
		"grid_x": grid_pos.x,
		"grid_y": grid_pos.y,
		"world_x": global_position.x,
		"world_y": global_position.y,
		"growth_stage": growth_stage,
		"growth_progress_minutes": growth_progress_minutes,
		"watered": watered,
		"mature": mature,
		"planted_day": planted_day,
		"planted_hour": planted_hour,
		"planted_minute": planted_minute
	}
