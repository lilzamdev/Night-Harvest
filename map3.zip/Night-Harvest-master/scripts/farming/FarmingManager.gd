extends Node2D
class_name FarmingManager

## Central Farming Controller for Night Harvest.
## Coordinates hoed soil, watering states, crop instances, and GameClock growth.
## Integrates multi-layer visuals:
## - TerrainLayer: Farmland dirt (FarmLand_Tile.png, Source 9)
## - ThingsLayer: Hoed furrow ridges (tile3.png, Source 4)
## - ThingsOverlayLayer: Planted crop entities and seeds

signal soil_hoed(grid_pos: Vector2i)
signal soil_unhoed(grid_pos: Vector2i)
signal seed_planted(grid_pos: Vector2i, crop_id: String)
signal soil_watered(grid_pos: Vector2i)
signal crop_harvested(grid_pos: Vector2i, crop_id: String, amount: int)
signal farming_xp_gained(amount: int, total_xp: int)


const CropEntityScene = preload("res://Scenes/farming/CropEntity.tscn")
const CropDataClass = preload("res://scripts/farming/CropData.gd")
const SoilStateClass = preload("res://scripts/farming/SoilState.gd")
const ItemDataClass = preload("res://scripts/item_data.gd")
const FARMLAND_TEXTURE_PATH := "res://Assets/Tiles/FarmLand_Tile.png"


const TILE3_TEXTURE_PATH := "res://Assets/Tiles/tile3.png"

@export var tile_size: float = 16.0
@export var default_growth_minutes: float = 30.0


# --- Configurable Farming XP ---
@export var xp_hoe: int = 1
@export var xp_plant: int = 2
@export var xp_water: int = 1
@export var xp_harvest: int = 10

var total_farming_xp: int = 0

## Dictionary mapping Vector2i grid_pos -> Dictionary:
## { "state": SoilState.State, "crop": CropEntity }
var _farm_tiles: Dictionary = {}

# Multi-layer references from game scene
var _terrain_layer: TileMapLayer = null
var _things_layer: TileMapLayer = null
var _overlay_layer: TileMapLayer = null

var _terrain_source_id: int = -1
var _things_source_id: int = -1
var _overlay_source_id: int = -1

# Fallback layer for standalone/headless unit tests if no map exists
var _soil_layer: TileMapLayer = null
var _crops_container: Node2D = null
var _game_clock: Node = null
var _selector_cursor: FarmingCursor = null


func _ready() -> void:
	add_to_group("farming_manager")
	
	_bind_map_layers()
	_setup_crops_container()
	_setup_fallback_soil_layer()
	_setup_selector_cursor()
	call_deferred("_connect_game_clock")


func set_map_layers(terrain: TileMapLayer, things: TileMapLayer = null, overlay: TileMapLayer = null) -> void:
	_terrain_layer = terrain
	_things_layer = things
	_overlay_layer = overlay
	if _soil_layer and is_instance_valid(_soil_layer):
		_soil_layer.queue_free()
		_soil_layer = null
	_detect_source_ids()
	_setup_crops_container()
	_scan_existing_farm_tiles()



func _bind_map_layers() -> void:
	var parent_node := get_parent()
	if parent_node:
		_terrain_layer = parent_node.get_node_or_null("TileMap/TerrainLayer")
		if not _terrain_layer:
			_terrain_layer = parent_node.get_node_or_null("TerrainLayer")
	
	if not _terrain_layer and get_tree():
		var terrain_nodes := get_tree().get_nodes_in_group("terrain_layer")
		if not terrain_nodes.is_empty():
			_terrain_layer = terrain_nodes[0]
	
	if _terrain_layer:
		_things_layer = _terrain_layer.get_node_or_null("ThingsLayer")
		if _things_layer:
			_overlay_layer = _things_layer.get_node_or_null("ThingsOverlayLayer")
	
	_detect_source_ids()
	_scan_existing_farm_tiles()


func _detect_source_ids() -> void:
	if _terrain_layer and _terrain_layer.tile_set:
		_terrain_source_id = _find_source_id_by_texture_name(_terrain_layer.tile_set, "farmland_tile")
		if _terrain_source_id < 0 and _terrain_layer.tile_set.get_source_count() > 9:
			_terrain_source_id = 9
	
	if _things_layer and _things_layer.tile_set:
		_things_source_id = _find_source_id_by_texture_name(_things_layer.tile_set, "tile3")
		if _things_source_id < 0 and _things_layer.tile_set.get_source_count() > 4:
			_things_source_id = 4
	
	if _overlay_layer and _overlay_layer.tile_set:
		_overlay_source_id = _find_source_id_by_texture_name(_overlay_layer.tile_set, "outdoor_decor")
		if _overlay_source_id < 0 and _overlay_layer.tile_set.get_source_count() > 1:
			_overlay_source_id = 1


func _find_source_id_by_texture_name(ts: TileSet, name_substr: String) -> int:
	if not ts:
		return -1
	for i in range(ts.get_source_count()):
		var sid := ts.get_source_id(i)
		var src = ts.get_source(sid)
		if src is TileSetAtlasSource and src.texture:
			if name_substr.to_lower() in src.texture.resource_path.to_lower():
				return sid
	return -1


func _scan_existing_farm_tiles() -> void:
	if not _things_layer or _things_source_id < 0:
		return
	
	for cell in _things_layer.get_used_cells():
		var sid := _things_layer.get_cell_source_id(cell)
		if sid == _things_source_id:
			var coords := _things_layer.get_cell_atlas_coords(cell)
			if (coords.x == 10 or coords.x == 11) and (coords.y in [8, 9, 12, 13]):
				var is_watered: bool = (coords.y in [8, 9])
				if not _farm_tiles.has(cell):
					_farm_tiles[cell] = {
						"state": SoilStateClass.State.WATERED if is_watered else SoilStateClass.State.HOED,
						"crop": null
					}


func _setup_crops_container() -> void:
	if _crops_container and is_instance_valid(_crops_container):
		# Re-parent to overlay layer if not already parented there
		if _overlay_layer and is_instance_valid(_overlay_layer) and _crops_container.get_parent() != _overlay_layer:
			_crops_container.get_parent().remove_child(_crops_container)
			_overlay_layer.add_child(_crops_container)
		return
	
	_crops_container = Node2D.new()
	_crops_container.name = "CropsContainer"
	_crops_container.y_sort_enabled = true
	
	if _overlay_layer and is_instance_valid(_overlay_layer):
		_overlay_layer.add_child(_crops_container)
	else:
		add_child(_crops_container)


func _setup_fallback_soil_layer() -> void:
	# Fallback soil layer is STRICTLY for standalone unit tests when no real TerrainLayer exists.
	# If a real terrain layer exists, fallback layer must NEVER exist to prevent duplicate tiles.
	if _terrain_layer != null:
		if _soil_layer and is_instance_valid(_soil_layer):
			_soil_layer.queue_free()
			_soil_layer = null
		return
	
	if _soil_layer:
		return
	
	_soil_layer = get_node_or_null("FarmingSoilLayer")

	if not _soil_layer:
		_soil_layer = TileMapLayer.new()
		_soil_layer.name = "FarmingSoilLayer"
		
		var ts := TileSet.new()
		ts.tile_size = Vector2i(16, 16)
		
		var source := TileSetAtlasSource.new()
		var tex = load(FARMLAND_TEXTURE_PATH)
		if tex:
			source.texture = tex
			source.texture_region_size = Vector2i(16, 16)
			for y in range(3):
				for x in range(3):
					source.create_tile(Vector2i(x, y))
					var alt_id := source.create_alternative_tile(Vector2i(x, y))
					var tile_data := source.get_tile_data(Vector2i(x, y), alt_id)
					if tile_data:
						tile_data.modulate = Color(0.55, 0.48, 0.40, 1.0)
		
		ts.add_source(source, 0)
		_soil_layer.tile_set = ts
		add_child(_soil_layer)


func _connect_game_clock() -> void:
	var clocks := get_tree().get_nodes_in_group("game_clock")
	for c in clocks:
		if is_instance_valid(c):
			_game_clock = c
			break
	
	if _game_clock:
		if not _game_clock.time_updated.is_connected(_on_game_clock_time_updated):
			_game_clock.time_updated.connect(_on_game_clock_time_updated)
		if not _game_clock.day_changed.is_connected(_on_game_clock_day_changed):
			_game_clock.day_changed.connect(_on_game_clock_day_changed)


func _on_game_clock_time_updated(_hour: int, _minute: int) -> void:
	advance_growth_minutes(1.0)


func _on_game_clock_day_changed(_new_day: int) -> void:
	for grid_pos in _farm_tiles.keys():
		var cell: Dictionary = _farm_tiles[grid_pos]
		if cell.get("state") == SoilStateClass.State.WATERED:
			cell["state"] = SoilStateClass.State.HOED
			if cell.get("crop") and is_instance_valid(cell["crop"]):
				cell["crop"].set_watered(false)
			_update_soil_tile_visual(grid_pos)


## Advances growth on all planted crops by specified game minutes
func advance_growth_minutes(amount: float) -> void:
	for grid_pos in _farm_tiles.keys():
		var cell: Dictionary = _farm_tiles[grid_pos]
		var crop: Node2D = cell.get("crop", null)
		if crop and is_instance_valid(crop) and crop.has_method("advance_game_minute"):
			crop.advance_game_minute(amount)


# ==============================================================================
# COORDINATE CONVERSIONS
# ==============================================================================

func world_to_grid(world_pos: Vector2) -> Vector2i:
	if _terrain_layer:
		return _terrain_layer.local_to_map(_terrain_layer.to_local(world_pos))
	elif _things_layer:
		return _things_layer.local_to_map(_things_layer.to_local(world_pos))
	elif _soil_layer:
		return _soil_layer.local_to_map(_soil_layer.to_local(world_pos))
	return Vector2i(int(floor(world_pos.x / tile_size)), int(floor(world_pos.y / tile_size)))


func grid_to_world(grid_pos: Vector2i) -> Vector2:
	if _terrain_layer:
		return _terrain_layer.to_global(_terrain_layer.map_to_local(grid_pos))
	elif _things_layer:
		return _things_layer.to_global(_things_layer.map_to_local(grid_pos))
	elif _soil_layer:
		return _soil_layer.to_global(_soil_layer.map_to_local(grid_pos))
	return Vector2(grid_pos.x * tile_size + (tile_size * 0.5), grid_pos.y * tile_size + (tile_size * 0.5))


func _get_furrow_coords(grid_pos: Vector2i, is_watered: bool) -> Vector2i:
	var col_offset: int = abs(grid_pos.x) % 2
	var row_offset: int = abs(grid_pos.y) % 2
	var base_row: int = 8 if is_watered else 12
	return Vector2i(10 + col_offset, base_row + row_offset)


# ==============================================================================
# HOE / TILLING SYSTEM
# ==============================================================================

## Validates whether the given location can be hoed into plantable farmland
func can_hoe_tile(world_pos: Vector2) -> bool:
	var grid_pos := world_to_grid(world_pos)
	
	# Check if already hoed or watered in tracking dictionary
	if _farm_tiles.has(grid_pos):
		var state: int = _farm_tiles[grid_pos].get("state", SoilStateClass.State.UNTILLED)
		if state == SoilStateClass.State.HOED or state == SoilStateClass.State.WATERED:
			return false
	
	# If ThingsLayer already has a furrow here, it is already hoed
	if _things_layer and _things_source_id >= 0:
		var sid := _things_layer.get_cell_source_id(grid_pos)
		if sid == _things_source_id:
			var coords := _things_layer.get_cell_atlas_coords(grid_pos)
			if (coords.x == 10 or coords.x == 11) and (coords.y in [8, 9, 12, 13]):
				if not _farm_tiles.has(grid_pos):
					var is_watered: bool = (coords.y in [8, 9])
					_farm_tiles[grid_pos] = {
						"state": SoilStateClass.State.WATERED if is_watered else SoilStateClass.State.HOED,
						"crop": null
					}
				return false
	
	# Check physics obstacles (buildings, trees, fences)
	if not _is_tile_passable_and_clear(world_pos):
		return false
	
	# Check invalid terrain (cliffs, water)
	if _terrain_layer:
		var sid := _terrain_layer.get_cell_source_id(grid_pos)
		if sid in [13, 15, 16]: # Cliff / Water tiles
			return false
	
	return true


## Converts normal ground into Hoed plantable soil with farmland dirt and furrows
func hoe_tile(world_pos: Vector2) -> bool:
	if not can_hoe_tile(world_pos):
		return false
	
	var grid_pos := world_to_grid(world_pos)
	var prev_sid := -1
	var prev_coords := Vector2i.ZERO
	var prev_alt := 0
	if _terrain_layer:
		prev_sid = _terrain_layer.get_cell_source_id(grid_pos)
		prev_coords = _terrain_layer.get_cell_atlas_coords(grid_pos)
		prev_alt = _terrain_layer.get_cell_alternative_tile(grid_pos)
	
	_farm_tiles[grid_pos] = {
		"state": SoilStateClass.State.HOED,
		"crop": null,
		"prev_terrain": {
			"sid": prev_sid,
			"coords": prev_coords,
			"alt": prev_alt
		}
	}
	
	_update_soil_tile_visual(grid_pos)
	_award_xp(xp_hoe)
	soil_hoed.emit(grid_pos)
	return true


## Validates whether target tile can be safely unhoed (reverted to normal ground).
## Strict rule: CANNOT UNHOE if any crop exists (seed, sprout, growing, or mature).
func can_unhoe_tile(world_pos: Vector2) -> bool:
	var grid_pos := world_to_grid(world_pos)
	if not _farm_tiles.has(grid_pos):
		return false
	
	var cell: Dictionary = _farm_tiles[grid_pos]
	
	# Crop protection: cannot unhoe if occupied by a crop at any stage
	var crop: Node2D = cell.get("crop", null)
	if crop != null and is_instance_valid(crop):
		return false
	
	var state: int = cell.get("state", SoilStateClass.State.UNTILLED)
	return (state == SoilStateClass.State.HOED or state == SoilStateClass.State.WATERED)


## Unhoes empty hoed soil and reverts terrain to normal ground
func unhoe_tile(world_pos: Vector2) -> bool:
	if not can_unhoe_tile(world_pos):
		return false
	
	var grid_pos := world_to_grid(world_pos)
	var cell: Dictionary = _farm_tiles[grid_pos]
	var prev: Dictionary = cell.get("prev_terrain", {})
	
	# 1. Clear furrow on ThingsLayer
	if _things_layer and _things_source_id >= 0:
		_things_layer.set_cell(grid_pos, -1)
	
	# 2. Revert TerrainLayer to previous or clear
	if _terrain_layer:
		if prev.has("sid") and prev["sid"] != -1 and prev["sid"] != _terrain_source_id:
			_terrain_layer.set_cell(grid_pos, prev["sid"], prev.get("coords", Vector2i.ZERO), prev.get("alt", 0))
		else:
			_terrain_layer.set_cell(grid_pos, -1)
	
	# 3. Clear fallback layer if active
	if _soil_layer:
		_soil_layer.set_cell(grid_pos, -1)
	
	_farm_tiles.erase(grid_pos)
	soil_unhoed.emit(grid_pos)
	return true


# ==============================================================================
# SEED / PLANTING SYSTEM
# ==============================================================================

## Validates if seed can be planted on target tile
func can_plant_seed(world_pos: Vector2, seed_id: String) -> bool:
	var grid_pos := world_to_grid(world_pos)
	if not _farm_tiles.has(grid_pos):
		# Also check if ThingsLayer has furrow
		if _things_layer and _things_source_id >= 0:
			var sid := _things_layer.get_cell_source_id(grid_pos)
			if sid == _things_source_id:
				var coords := _things_layer.get_cell_atlas_coords(grid_pos)
				if (coords.x == 10 or coords.x == 11) and (coords.y in [8, 9, 12, 13]):
					_farm_tiles[grid_pos] = {
						"state": SoilStateClass.State.HOED,
						"crop": null
					}
		if not _farm_tiles.has(grid_pos):
			return false
	
	var cell: Dictionary = _farm_tiles[grid_pos]
	var state: int = cell.get("state", SoilStateClass.State.UNTILLED)
	
	# Must be hoed or watered soil
	if state != SoilStateClass.State.HOED and state != SoilStateClass.State.WATERED:
		return false
	
	# Must not already be occupied by a crop
	if cell.get("crop") != null and is_instance_valid(cell.get("crop")):
		return false
	
	if seed_id.is_empty():
		return false
	
	return true


## Plants seed at target tile, creates CropEntity in ThingsOverlayLayer, and tracks growth
func plant_seed(world_pos: Vector2, seed_id: String) -> Node2D:
	if not can_plant_seed(world_pos, seed_id):
		return null
	
	var grid_pos := world_to_grid(world_pos)
	var cell: Dictionary = _farm_tiles[grid_pos]
	
	var crop_data: Resource = CropDataClass.get_crop_data_by_seed(seed_id)
	if not crop_data:
		crop_data = CropDataClass.create_carrot()
	
	var crop_node: Node2D = CropEntityScene.instantiate()
	if not _crops_container or not is_instance_valid(_crops_container):
		_setup_crops_container()
	_crops_container.add_child(crop_node)
	
	var tile_center := grid_to_world(grid_pos)
	crop_node.global_position = tile_center
	
	var current_time := {
		"day": _game_clock.current_day if _game_clock else 1,
		"hour": _game_clock.current_hour if _game_clock else 6,
		"minute": _game_clock.current_minute if _game_clock else 0
	}
	
	crop_node.setup(crop_data, grid_pos, false, current_time)
	cell["crop"] = crop_node
	
	crop_node.tree_exiting.connect(func():
		if _farm_tiles.has(grid_pos) and _farm_tiles[grid_pos].get("crop") == crop_node:
			_farm_tiles[grid_pos]["crop"] = null
	)
	
	_award_xp(xp_plant)
	if seed_id == "carrot_seed":
		_notify_event_bus("carrot_planted")
	_notify_event_bus("crop_planted", [seed_id])
	seed_planted.emit(grid_pos, crop_data.crop_id)
	
	return crop_node


# ==============================================================================
# WATERING SYSTEM
# ==============================================================================

## Validates if target tile can be watered.
## Phase 1.5 Rule: Empty hoed soil CANNOT be watered.
## Watering only applies if there is a living, non-mature crop that requires water.
func can_water(world_pos: Vector2) -> bool:
	var grid_pos := world_to_grid(world_pos)
	if not _farm_tiles.has(grid_pos):
		return false
	
	var cell: Dictionary = _farm_tiles[grid_pos]
	var crop: Node2D = cell.get("crop", null)
	if not crop or not is_instance_valid(crop):
		# No crop on soil -> cannot water empty hoed soil!
		return false
	
	if crop.has_method("can_be_watered"):
		return crop.can_be_watered()
	return not crop.get("watered") and not crop.get("mature")


## Waters the planted crop.
## Phase 1.5 Rule: Ground tile is NOT changed; soil remains clean HOED soil.
## Watering strictly affects the crop's internal state and triggers splash feedback.
func water_tile(world_pos: Vector2) -> bool:
	if not can_water(world_pos):
		return false
	
	var grid_pos := world_to_grid(world_pos)
	var cell: Dictionary = _farm_tiles[grid_pos]
	var crop: Node2D = cell.get("crop", null)
	
	if crop and is_instance_valid(crop) and crop.has_method("set_watered"):
		crop.set_watered(true)
	
	# Ground tile is NOT replaced or altered; soil remains HOED.
	_spawn_water_splash(grid_to_world(grid_pos))
	_award_xp(xp_water)
	_notify_event_bus("crop_watered")
	soil_watered.emit(grid_pos)
	
	return true


# ==============================================================================
# HARVESTING SYSTEM
# ==============================================================================

## Validates if target tile has a mature crop ready for harvest
func can_harvest(world_pos: Vector2) -> bool:
	var grid_pos := world_to_grid(world_pos)
	if not _farm_tiles.has(grid_pos):
		return false
	
	var crop: Node2D = _farm_tiles[grid_pos].get("crop", null)
	if crop and is_instance_valid(crop):
		if crop.has_method("can_harvest"):
			return crop.can_harvest()
		elif crop.has_method("is_mature"):
			return crop.is_mature()
	return false


## Harvests the mature crop, awards crop yield AND renewable replacement seeds to player inventory
func harvest_crop(world_pos: Vector2, target_inventory: Object = null) -> Dictionary:
	if not can_harvest(world_pos):
		return {}
	
	var grid_pos := world_to_grid(world_pos)
	var crop: Node2D = _farm_tiles[grid_pos].get("crop", null)
	if not crop or not is_instance_valid(crop):
		return {}
	
	var result: Dictionary = crop.harvest()
	var item_id: String = result.get("item_id", "carrot")
	var amount: int = result.get("amount", 1)
	var seed_id: String = result.get("seed_id", "carrot_seed")
	var seed_amount: int = result.get("seed_amount", 1)
	var xp_amt: int = result.get("xp", xp_harvest)
	
	if not target_inventory:
		target_inventory = _find_inventory()
	
	if target_inventory and target_inventory.has_method("add_item"):
		var db = load("res://scripts/item_database.gd")
		var crop_resource = db.get_item(item_id)
		if crop_resource:
			target_inventory.call("add_item", crop_resource, amount)
		var seed_resource = db.get_item(seed_id)
		if seed_resource:
			target_inventory.call("add_item", seed_resource, seed_amount)
	
	# Soil remains hoed for replanting
	if _farm_tiles.has(grid_pos):
		_farm_tiles[grid_pos]["crop"] = null
		_farm_tiles[grid_pos]["state"] = SoilStateClass.State.HOED
	
	_award_xp(xp_amt)
	_notify_event_bus("crop_harvested", [item_id])
	crop_harvested.emit(grid_pos, item_id, amount)
	
	return result



func get_crop_at(world_pos: Vector2) -> Node2D:
	var grid_pos := world_to_grid(world_pos)
	if _farm_tiles.has(grid_pos):
		var crop = _farm_tiles[grid_pos].get("crop", null)
		if crop and is_instance_valid(crop):
			return crop as Node2D
	return null


func get_soil_state(world_pos: Vector2) -> int:
	var grid_pos := world_to_grid(world_pos)
	if _farm_tiles.has(grid_pos):
		return _farm_tiles[grid_pos].get("state", SoilStateClass.State.UNTILLED)
	return SoilStateClass.State.UNTILLED


# ==============================================================================
# MULTI-LAYER SOIL VISUALIZATION
# ==============================================================================

func _update_soil_tile_visual(grid_pos: Vector2i) -> void:
	if not _farm_tiles.has(grid_pos):
		if _things_layer and _things_source_id >= 0:
			_things_layer.set_cell(grid_pos, -1)
		elif _soil_layer:
			_soil_layer.set_cell(grid_pos, -1)
		return
	
	var state: int = _farm_tiles[grid_pos].get("state", SoilStateClass.State.UNTILLED)
	
	match state:
		SoilStateClass.State.HOED:
			# 1. Base dirt on TerrainLayer (FarmLand_Tile.png, Source 9, coords (1, 1), alt 0)
			if _terrain_layer and _terrain_source_id >= 0:
				var cur_sid := _terrain_layer.get_cell_source_id(grid_pos)
				if cur_sid != _terrain_source_id:
					_terrain_layer.set_cell(grid_pos, _terrain_source_id, Vector2i(1, 1), 0)
			
			# 2. Hoed furrow on ThingsLayer (tile3.png, Source 4, dry rows 12-13)
			if _things_layer and _things_source_id >= 0:
				var coords := _get_furrow_coords(grid_pos, false)
				_things_layer.set_cell(grid_pos, _things_source_id, coords, 0)
			elif _soil_layer:
				_soil_layer.set_cell(grid_pos, 0, Vector2i(1, 1), 0)
				
		SoilStateClass.State.WATERED:
			# 1. Base dirt on TerrainLayer
			if _terrain_layer and _terrain_source_id >= 0:
				var cur_sid := _terrain_layer.get_cell_source_id(grid_pos)
				if cur_sid != _terrain_source_id:
					_terrain_layer.set_cell(grid_pos, _terrain_source_id, Vector2i(1, 1), 0)
			
			# 2. Moist furrow on ThingsLayer (tile3.png, Source 4, moist rows 8-9)
			if _things_layer and _things_source_id >= 0:
				var coords := _get_furrow_coords(grid_pos, true)
				_things_layer.set_cell(grid_pos, _things_source_id, coords, 0)
			elif _soil_layer:
				_soil_layer.set_cell(grid_pos, 0, Vector2i(1, 1), 1)
				
		SoilStateClass.State.UNTILLED, _:
			if _things_layer and _things_source_id >= 0:
				_things_layer.set_cell(grid_pos, -1)
			elif _soil_layer:
				_soil_layer.set_cell(grid_pos, -1)


# ==============================================================================
# HELPERS & REWARDS
# ==============================================================================

func _award_xp(amount: int) -> void:
	total_farming_xp += amount
	farming_xp_gained.emit(amount, total_farming_xp)
	
	var stats_nodes := get_tree().get_nodes_in_group("player_stats")
	for s in stats_nodes:
		if is_instance_valid(s) and s.has_method("add_xp"):
			s.add_xp(amount)
			break


func _is_tile_passable_and_clear(world_pos: Vector2) -> bool:
	var space := get_world_2d().direct_space_state
	if not space:
		return true
	
	var query := PhysicsPointQueryParameters2D.new()
	query.position = world_pos
	query.collision_mask = 1 # Solid world obstacles / trees / chests / walls
	query.collide_with_areas = false
	query.collide_with_bodies = true
	
	var hits := space.intersect_point(query)
	return hits.is_empty()


func _find_inventory() -> Control:
	var nodes := get_tree().get_nodes_in_group("inventory_ui")
	for n in nodes:
		if is_instance_valid(n):
			return n as Control
	return null


func _notify_event_bus(signal_name: String, args: Array = []) -> void:
	var bus_nodes := get_tree().get_nodes_in_group("event_bus")
	for bus in bus_nodes:
		if is_instance_valid(bus) and bus.has_signal(signal_name):
			match args.size():
				0: bus.emit_signal(signal_name)
				1: bus.emit_signal(signal_name, args[0])
				2: bus.emit_signal(signal_name, args[0], args[1])
			break


## Save/Load Serialization support for Phase 1
func get_save_data() -> Dictionary:
	var crops_data: Array = []
	var tiles_data: Array = []
	
	for grid_pos in _farm_tiles.keys():
		var cell: Dictionary = _farm_tiles[grid_pos]
		tiles_data.append({
			"x": grid_pos.x,
			"y": grid_pos.y,
			"state": cell.get("state", 0)
		})
		var crop: Node2D = cell.get("crop", null)
		if crop and is_instance_valid(crop) and crop.has_method("get_save_data"):
			crops_data.append(crop.get_save_data())
	
	return {
		"total_farming_xp": total_farming_xp,
		"farm_tiles": tiles_data,
		"crops": crops_data
	}


func _spawn_water_splash(pos: Vector2) -> void:
	if not is_inside_tree():
		return
	var splash := CPUParticles2D.new()
	splash.emitting = true
	splash.one_shot = true
	splash.explosiveness = 0.95
	splash.amount = 12
	splash.lifetime = 0.4
	splash.direction = Vector2(0, -1)
	splash.spread = 60.0
	splash.gravity = Vector2(0, 98.0)
	splash.initial_velocity_min = 25.0
	splash.initial_velocity_max = 50.0
	splash.scale_amount_min = 1.5
	splash.scale_amount_max = 3.0
	splash.color = Color(0.25, 0.65, 1.0, 0.9)
	splash.global_position = pos
	splash.z_index = 40
	add_child(splash)
	get_tree().create_timer(0.5).timeout.connect(splash.queue_free)


func _setup_selector_cursor() -> void:
	if _selector_cursor and is_instance_valid(_selector_cursor):
		return
	_selector_cursor = FarmingCursor.new()
	_selector_cursor.name = "FarmingCursor"
	_selector_cursor.z_index = 60
	add_child(_selector_cursor)


var _growth_time_accumulator: float = 0.0


func _process(delta: float) -> void:
	_update_selector_cursor()
	if _game_clock == null:
		_growth_time_accumulator += delta
		while _growth_time_accumulator >= 1.0:
			_growth_time_accumulator -= 1.0
			advance_growth_minutes(1.0)



func _update_selector_cursor() -> void:
	if not _selector_cursor or not is_instance_valid(_selector_cursor):
		return
	
	var player = _get_player()
	if not player:
		if _selector_cursor.is_active:
			_selector_cursor.is_active = false
			_selector_cursor.queue_redraw()
		return
	
	var held = player.get("current_held_item")
	var is_farming_tool := false
	var tool_type: int = -1
	var item_id: String = ""
	
	if held:
		var id_val = held.get("item_id")
		item_id = str(id_val) if id_val != null else ""
		var action_val = held.get("action_type")
		var action_type: int = int(action_val) if action_val != null else -1
		var type_val = held.get("item_type")
		var item_type: int = int(type_val) if type_val != null else -1
		
		if action_type == ItemDataClass.ActionType.TILL or item_id == "hoe":
			is_farming_tool = true
			tool_type = ItemDataClass.ActionType.TILL
		elif action_type == ItemDataClass.ActionType.WATER or item_id == "watering_can":
			is_farming_tool = true
			tool_type = ItemDataClass.ActionType.WATER
		elif item_type == ItemDataClass.ItemType.SEED or action_type == ItemDataClass.ActionType.PLANT:
			is_farming_tool = true
			tool_type = ItemDataClass.ActionType.PLANT

	
	if not is_farming_tool:
		if _selector_cursor.is_active:
			_selector_cursor.is_active = false
			_selector_cursor.queue_redraw()
		return
	
	var mpos := get_global_mouse_position()
	var gpos := world_to_grid(mpos)
	var snap_pos := grid_to_world(gpos)
	
	_selector_cursor.global_position = snap_pos
	_selector_cursor.is_active = true
	_selector_cursor.in_reach = player.global_position.distance_to(snap_pos) <= 64.0
	
	match tool_type:
		ItemDataClass.ActionType.TILL:
			var can_hoe = can_hoe_tile(snap_pos)
			var can_unhoe = can_unhoe_tile(snap_pos)
			_selector_cursor.is_valid = can_hoe or can_unhoe
			_selector_cursor.is_unhoe_mode = can_unhoe
		ItemDataClass.ActionType.WATER:
			_selector_cursor.is_valid = can_water(snap_pos)
			_selector_cursor.is_unhoe_mode = false
		ItemDataClass.ActionType.PLANT:
			_selector_cursor.is_valid = can_plant_seed(snap_pos, item_id)
			_selector_cursor.is_unhoe_mode = false
		_:
			_selector_cursor.is_valid = false
			_selector_cursor.is_unhoe_mode = false
			
	_selector_cursor.queue_redraw()


func _get_player() -> Node2D:
	if get_tree():
		var ken_nodes = get_tree().get_nodes_in_group("player")
		if not ken_nodes.is_empty() and is_instance_valid(ken_nodes[0]):
			return ken_nodes[0] as Node2D
		var root = get_tree().current_scene
		if root and is_instance_valid(root):
			var ken = root.find_child("*ken*", true, false)
			if ken is Node2D:
				return ken
	return null


class FarmingCursor extends Node2D:
	var is_active: bool = false
	var in_reach: bool = false
	var is_valid: bool = false
	var is_unhoe_mode: bool = false
	
	func _draw() -> void:
		if not is_active:
			return
		var col: Color
		if not in_reach:
			col = Color(1.0, 0.25, 0.25, 0.55) # Out of reach
		elif is_valid:
			if is_unhoe_mode:
				col = Color(0.2, 0.85, 1.0, 0.85) # Cyan when hovering empty soil to unhoe
			else:
				col = Color(0.2, 1.0, 0.4, 0.8) # Green when hovering untilled soil to till
		else:
			col = Color(1.0, 0.75, 0.2, 0.65) # Amber/yellow when invalid or protected crop
		
		# Draw clean 16x16 border box centered on tile
		draw_rect(Rect2(-8, -8, 16, 16), col, false, 1.5)
		# Draw subtle semi-transparent fill
		draw_rect(Rect2(-7, -7, 14, 14), Color(col.r, col.g, col.b, 0.12), true)
